package edu.eci.arsw.api.primesrepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimesrepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimesrepoApplication.class, args);
	}
}
