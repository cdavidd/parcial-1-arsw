package edu.eci.arsw.api.primesrepo;

import edu.eci.arsw.api.primesrepo.model.FoundPrime;
import edu.eci.arsw.api.primesrepo.service.PrimeService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMethod;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

/**
 * @author Santiago Carrillo
 * 2/22/18.
 */
@RestController
@RequestMapping(value = "/blueprints")
public class PrimesController
{
    @Autowired
    PrimeService primeService;


    @RequestMapping( method = RequestMethod.GET )
    public List<FoundPrime> getPrimes()
    {
        return primeService.getFoundPrimes();
    }
    
    @RequestMapping( method = RequestMethod.GET, path = "{primenumber}")
    public List<FoundPrime> getPrimesNumber(@PathVariable("primenumber") String authorName)
    {
        return (List<FoundPrime>) primeService.getPrime(authorName);
    }

    @RequestMapping(method = RequestMethod.POST, path = "{primenumber}")
    public void addPrimesNumber(@RequestBody FoundPrime foundPrime)
    {
        try{
            primeService.addFoundPrime(foundPrime);
        }catch(Exception ex){
            //
        }
        
    }
    //TODO implement additional methods provided by PrimeService



}
