package edu.eci.arsw.primefinder;

import edu.eci.arsw.mouseutils.MouseMovementMonitor;
import edu.eci.arsw.threads.Hilos;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

public class PrimesFinderTool {
        static Hilos t1;
        static Hilos t2;
        static Hilos  t3;
        static Hilos t4;
        static PrimesResultSet prs;
        static boolean pausa = false;
        public static boolean fin = true;
        
	public static void main(String[] args) {
            
            int maxPrim=1000;
            /*
            PrimesResultSet prst=new PrimesResultSet("john");
            PrimeFinder.findPrimes(new BigInteger("1"), new BigInteger("10"), prst);
            System.out.println("Prime numbers found:");
            System.out.println(prst.getPrimes());
            */
            
            prs=new PrimesResultSet("john");
            t1 = new Hilos(new BigInteger("1"), new BigInteger("20"), prs);
            t2 = new Hilos(new BigInteger("21"), new BigInteger("50"),prs);
            t3 = new Hilos(new BigInteger("51"), new BigInteger("70"),prs);
            t4 = new Hilos(new BigInteger("71"), new BigInteger("100"), prs);
            
            t1.start();
            t2.start();
            t3.start();
            t4.start();

            //task_not_finished
            while(fin){
                try {
                    //check every 10ms if the idle status (10 seconds without mouse
                    //activity) was reached. 
                    //System.out.println(MouseMovementMonitor.getInstance().getTimeSinceLastMouseMovement()>10000);
                    Thread.sleep(10);
                    if (MouseMovementMonitor.getInstance().getTimeSinceLastMouseMovement()>10000){
                        if (!pausa){
                            t1.suspend();t2.suspend();t3.suspend();t4.suspend();
                        }
                        pausa = true;
                        System.out.println("Idle CPU ");
                    }
                    else{
                        //terminar();
                        if (!pausa){
                            t1.resume();t2.resume();t3.resume();t4.resume();
                        }
                        pausa = false;
                        if (t1.getState()==t1.getState().TERMINATED && t2.getState()==t2.getState().TERMINATED && t3.getState()==t3.getState().TERMINATED && t4.getState()==t4.getState().TERMINATED){
                            fin = false;
                        }
                        //System.out.println(t1.getState()==t1.getState().TERMINATED && t2.getState()==t2.getState().TERMINATED && t3.getState()==t3.getState().TERMINATED && t4.getState()==t4.getState().TERMINATED);
                        System.out.println("User working again!");
                    }
                } catch (InterruptedException ex) {
                    Logger.getLogger(PrimesFinderTool.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            System.out.println(prs.getPrimes());
            
	}
        
        /*
        private static void terminar(){
            t1.resume();t2.resume();t3.resume();t4.resume();
            try{
                t1.join();
                t2.join();
                t3.join();
                t4.join();
            }catch(InterruptedException ex){
                System.out.println("error");
            }
            fin = false;
            System.out.println(prs.getPrimes());
        }
        */
}


