/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.eci.arsw.threads;

import edu.eci.arsw.primefinder.PrimeFinder;
import edu.eci.arsw.primefinder.PrimesResultSet;
import java.math.BigInteger;
import java.util.Collection;

/**
 *
 * @author 2133561
 */
public class Hilos extends Thread{
    BigInteger a;
    BigInteger b;
    PrimesResultSet prs;
    public Hilos (BigInteger a , BigInteger b, PrimesResultSet prs){
        super();
        this.a=a;
        this.b=b;
        this.prs=prs;
    }
    
    public Collection res(){
        return prs.getPrimes();
    }
            
    @Override
    public void run(){
        PrimeFinder.findPrimes(a, b, prs);
    }
    
}
